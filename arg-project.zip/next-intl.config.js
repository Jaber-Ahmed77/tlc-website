module.exports = {
  locales: ['en', 'ar'], // Add the locales you want to support
  defaultLocale: 'en',   // The default locale
  defaultNamespace: 'common', // The default namespace for your translations
};
