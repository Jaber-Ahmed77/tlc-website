"use client";

import React from "react";
import TwitterFeed from "./TwitterFeed";
import Btn from "./ui/btns/Btn";
import { FaArrowRight } from "react-icons/fa6";
import Slider from "./Slider";
import { SwiperSlide } from "swiper/react";
import Image from "next/image";
import Link from "next/link";
import { useTranslations } from "next-intl";

export default function OurNews({ locale }) {

  const t = useTranslations("common")

  const projects = [
    {
      id: 1,
      title:
        " Bisha Cement Plant Awarded to TLC Trading & Contracting Co. a prestigious ",
      description:
        " Bisha Cement Plant Awarded to TLC Trading & Contracting Co. a prestigious project for Fabrication and Installation of vent duct...",
      image: "/projects/proj-1.webp",
    },
    {
      id: 2,
      title: "  Construction of 132kV Double Circuit ",
      description:
        "Overhead Line from S/S 8068(Huraimala) to S/S 8502 (Hawat Sudayr) Location : Riyadh Client: Saudi Electricity Company Year of Completion:...",
      image: "/projects/proj-2.jpg",
    },
    {
      id: 3,
      title: "  Construction of a 115 kV double overhead circular line ",
      description:
        " from existing 115kV line of GOSP 1, 4, 5, 7 & 8 Location : Dammam Client: Saudi Aramco(MRK) Year of...",
      image: "/projects/proj-3.jpg",
    },
    {
      id: 4,
      title: " Construction of 132kV Double Circuit ",
      description:
        " Overhead Line from S/S 9009(PP#9) to S/S 8505(Rumah) Location : Riyadh Client: Saudi Electricity Company Year of Completion: 2005",
      image: "/projects/proj-4.jpg",
    },
  ];

  return (
    <section className="max-w-6xl mx-auto my-10 px-7 lg:px-0">
      <div className="flex flex-col md:flex-row justify-between gap-4 mb-10 md:items-center">
        <h3 className="text-2xl md:text-3xl  font-bold capitalize">
          <span className="text-blueShades-300">{t("ourNews.highlighted")}</span> {locale === "en"? t("ourNews.title") : "" }
        </h3>

        <Btn
          bg="bg-white text-xs md:px-6 md:py-2 md:text-lg w-fit"
          color="text-blueShades-300 border border-blueShades-300 font-bold"
          text={t("viewAll")}
          icon={<FaArrowRight />}
          rounded="rounded-3xl"
          hover="hover:bg-secondary hover:text-white"
        />
      </div>

      <div className="flex flex-col lg:flex-row gap-5 ">
        <div className="w-full flex overflow-x-auto gap-5 scrollbar-hide">
          <Slider
            slidesPerViewInDesktop={2}
            slidesPerViewInMobile={1}
            spaceBetweenInDesktop={20}
            spaceBetweenInMobile={10}
            customClass="w-full"
          >
            {projects.map((project, i) => (
              <SwiperSlide key={project.id}>
                <div className="flex flex-col h-full ">
                  <div className="w-full overflow-clip rounded-t-xl group">
                    <Image
                      width={500}
                      height={500}
                      src="/news.jpg"
                      alt="certificate"
                      className="w-full h-full group-hover:scale-125 transition-all duration-[2000ms] ease-in-out"
                    />
                  </div>
                  <div className="h-full flex flex-col justify-between p-5">
                    <p className=" font-semibold text-grayShades-100">
                      The Kingdom of Saudi Arabia has offered a number of
                      investment opportunities in the vaccines and vital
                      medicines industry with...{" "}
                    </p>
                    <Link
                      href={`/show/news?id=${project.id}`}
                      className="text-mainOrange flex items-center gap-2 hover:text-blueShades-300 capitalize transition-colors font-bold"
                    >
                      {t("more")} <FaArrowRight />
                    </Link>
                  </div>
                </div>
              </SwiperSlide>
            ))}
          </Slider>
        </div>
        <TwitterFeed />
      </div>
    </section>

    // <div></div>
  );
}
