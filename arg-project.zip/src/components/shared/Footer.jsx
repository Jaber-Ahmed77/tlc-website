import { useTranslations } from "next-intl";
import Link from "next/link";
import { CiLocationOn } from "react-icons/ci";
import { FaPhone } from "react-icons/fa";
import { FaFax } from "react-icons/fa";
import { FaGlobe } from "react-icons/fa";

export default function Footer() {

  const t = useTranslations("common");

  const contactInfo = [
    {
      icon: <CiLocationOn />,
      title: "P.O. Box 41763 Riyadh 11531",
      link: "https://maps.app.goo.gl/b76korSF1qJYAWzFA",
    },
    {
      icon: <FaPhone />,
      title: "966114977977+",
      link: "tel:+880 2 5555555",
    },
    {
      icon: <FaFax />,
      title: " 9660112083183+",
      link: "tel:+880 2 5555555",
    },
    {
      icon: <FaGlobe />,
      title: "info@TLC.com.sa",
      link: "mailto:abdullahnaser501@gmail.com",
    },
  ];

  return (
    <footer className="bg-[url('/footer-bg.png')] bg-contain bg-bottom pt-10 bg-no-repeat">
      <div className="max-w-6xl relative flex flex-col gap-14 lg:flex-row z-10 mx-auto mt-10 px-7 lg:px-0">
        <div className="flex flex-col gap-4 flex-1">
          <div className="flex flex-col md:flex-row justify-between gap-4 md:items-center ">
            <h3 className="text-2xl md:text-3xl  font-bold capitalize text-black  ">
              <span className="text-blueShades-300">{t("footer.highlighted")}</span> {t("footer.title")}:
            </h3>
          </div>

          <div className="flex flex-col gap-5 mt-10">
            {contactInfo.map((info, i) => (
              <div
                key={i}
                className="flex items-center gap-6 hover:text-mainOrange transition-colors text-black text-xl"
              >
                <span className="p-2 text-mainOrange rounded-lg shadow-md">
                  {info.icon}
                </span>
                <a
                  href={info.link}
                  className="text-lg font-semibold"
                  target="_blank"
                >
                  {info.title}
                </a>
              </div>
            ))}
          </div>
        </div>
        <div className="flex-1">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13735.476137675798!2d32.265172050000004!3d30.609457049999993!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14f85bd8a62981a1%3A0x4411045b24157dd!2sEl%20Salam%2C%20Ismailia%202%2C%20Ismailia%20Governorate!5e0!3m2!1sen!2seg!4v1734579830530!5m2!1sen!2seg"
            width="100%"
            height="100%"
            style={{ border: "0" }}
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          ></iframe>
        </div>
      </div>
      <p className="text-center mt-20 w-full">
        Developed by{" "}
        <Link href="https://www.arg.sa/" className="text-blueShades-300">
          ARG
        </Link>
      </p>
    </footer>
  );
}
